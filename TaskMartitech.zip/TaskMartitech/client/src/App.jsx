import { Route, Routes } from "react-router-dom"
import Home from "./components/Home"
import Menu from "./components/Menu"
import Authentication from "./components/Authentication";
import Login from "./components/Login";
import Register from "./components/Register";
import Cart from "./components/Cart";
import Checkout from "./components/Checkout";
import NotFoundPage from "./components/NotFoundPage";

function App() {
  return (
    <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/login" element={<Login/>}/>
        <Route path="/register" element={<Register/>}/>


        <Route element={<Authentication/>}>
          <Route path="/menu" element={<Menu/>}/>
          <Route path="/checkout" element={<Checkout/>}/>
          <Route path="/cart" element={<Cart/>}/>
      </Route>
       <Route path="*" element={<NotFoundPage/>}/>
    </Routes>
  )
}

export default App
