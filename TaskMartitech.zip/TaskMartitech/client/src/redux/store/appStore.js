import {configureStore} from "@reduxjs/toolkit";
import authSlice from "../slices/authSlice.js";
import menuSlice from "../slices/menuSlice.js"
import cartSlice from "../slices/cartSlice.js";

const appStore = configureStore({
    reducer:{
        auth:authSlice,
        menu:menuSlice,
        cart:cartSlice
    },
    devTools:true
})

export default appStore;