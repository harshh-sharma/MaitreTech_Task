import {createAsyncThunk, createSlice} from "@reduxjs/toolkit";
import axiosInstance from "../../helpers/axiosInstance";
import {toast} from "react-hot-toast";;

export const getMenuData = createAsyncThunk("/menuData",async() => {
    try {
        const response = axiosInstance.get("/menu/");
        toast.promise(response,{
            loading:"wait sometime for register",
            success:(data) => {
                console.log("data",data);
                return (data?.data?.message)
            },
            error:"failed to register"
        })
        return (await response).data;
    } catch (error) {
        return error;
    }
})

const menuSlice = createSlice({
    name:"menu",
    initialState:{
        data:"",
    },
    reducers:{},
    extraReducers:(builder) => {
        builder
                .addCase(getMenuData.fulfilled,(state,action) => {
                    // localStorage.setItem("menuData",JSON.parse(JSON.stringify(action.payload.data)));
                    console.log("pay",action?.payload?.menu);
                    state.data = JSON.parse(JSON.stringify(action?.payload?.menu));
                })
    }
})
// export const {} = menuSlice.actions;
export default menuSlice.reducer;