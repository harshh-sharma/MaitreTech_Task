import { createSlice } from "@reduxjs/toolkit";

const cartSlice  = createSlice({
    name:"cart",
    initialState:{
        items:[],

    },
    reducers:{
        addItemInCart:(state,action) => {
            console.log(action.payload);
            state.items.push(action.payload);
        },
        deleteItemInCart:(state,action) => {
            state.items.pop();
        }
    }
})

export const {addItemInCart,deleteItemInCart} = cartSlice.actions;
export default cartSlice.reducer;