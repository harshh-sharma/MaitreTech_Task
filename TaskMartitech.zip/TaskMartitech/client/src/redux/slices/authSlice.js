import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axiosInstance from "../../helpers/axiosInstance";
import toast from "react-hot-toast/headless";

export const register = createAsyncThunk("/register",async(data) => {
    try {
        const response = axiosInstance.post("/user/register",data);
        toast.promise(response,{
            loading:"wait sometime for register",
            success:(data) => {
                console.log("data",data);
                return (data?.data?.message)
            },
            error:"failed to register"
        })
        return (await response).data;
    } catch (error) {
        return error;
    }
})

export const login = createAsyncThunk("/user/login",async(data) => {
    try {
        const response = axiosInstance.post("/user/login",data);
        toast.promise(response,{
            loading:"wait sometime for login",
            success:(data) => {
                console.log("data",data);
                return (data?.data?.message)
            },
            error:"failed to login"
        })
        return (await response).data;
    } catch (error) {
        return error;
    }
})

const authSlice = createSlice({
    name:"auth",
    initialState:{
        isLoggedIn: false,
        userData: {},
        item:false
    },
    reducers:{},
    extraReducers:(builder) => {
        builder
                .addCase(login.fulfilled,(state,action) => {
                    // localStorage.setItem("isLoggedIn",true);
                    // localStorage.setItem("userData",JSON.stringify(data));
                    state.isLoggedIn = true;
                    // state.userData = action?.payload?.data
                })
    }
})

// const {addItem} = authSlice.actions;
export default authSlice.reducer;