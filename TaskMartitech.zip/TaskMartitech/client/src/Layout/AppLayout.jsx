import React from 'react'
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom'

const AppLayout = ({children}) => {
  const isLoggedIn = useSelector(store => store?.auth?.isLoggedIn);
  const {items} = useSelector(store => store?.cart);
  console.log(items);
  return (
    <div className='min-h-screen w-full'>
        <div className='bg-indigo-500 text-white w-full h-10 py-6 shadow-2xl flex justify-between px-2 md:px-10 items-center'>
            <span className='font-bold text-md md:text-xl'>Food Restaurant</span>
            {isLoggedIn ? <Link to={"/cart"}><span className='font-bold text-xl'>Cart <span className='absolute top-0 text-sm bg-red-400 rounded-full w-6 h-6 flex justify-center items-center right-4'>{items.length}</span></span></Link> : <div className='flex gap-2'>
               <button className='bg-white text-indigo-500 px-4 py-1 font-bold shadow-md rounded-full'>Register/Login</button>
               {/* <button className=' text-white px-4 font-bold py-1 shadow-md rounded-full border-2 border-white '>Login</button> */}
               </div> }
        </div>
        {children}
    </div>
  )
}

export default AppLayout