import React, { useState } from 'react'
import AppLayout from '../Layout/AppLayout'
import { login } from '../redux/slices/authSlice'
import toast from 'react-hot-toast'
import { Link, useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import axiosInstance from '../helpers/axiosInstance'

const Login = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [loginData,setLoginData] = useState({
        email:"",
        password:""   
     })

     const handleUserInput = (e) => {
        e.preventDefault();
        const {name,value} = e.target;
        setLoginData({
            ...loginData,
            [name]:value
        })
     }

     const validateForm = (email,password) => {
        if(!email || !password){
            toast.error("All fields are required");
            return false ;
        }else  if(password < 6){
            toast.error("wrong password");
            return false;
        } else if(!email.match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    )){
        toast.error("Invalid email");
        return false;
    }
    else{
        return true
    }
     }

     const handleUserSubmit = async (e) => {
        e.preventDefault();
        if(validateForm(loginData.email,loginData.password)){
            const response = await dispatch(login(loginData));
            if(response?.payload?.success){
                navigate("/menu");
            }
        }
     }

  return (
    <AppLayout>
        <div className='w-full min-h-screen bg-gradient-to-r from-gray-200 to-blue-500 rounded-md flex justify-center items-center flex-col gap-2'>
            <form className='flex flex-col gap-2 bg-gray-200 px-5 rounded-md w-[300px] py-10 '>
            <h1 className='text-xl font-semibold font-serif text-center text-indigo-500 '>Login</h1>
            <div className='flex flex-col gap-2  font-semibold'>
            <label htmlFor="email">Email</label>
            <input type="email" placeholder='Enter you Email' name="email" value={loginData.email} onChange={handleUserInput} className='bg-gray-300 border-2 rounded-md pr-10 pl-2 py-1'/>
            </div>
            <div className='flex flex-col gap-2 font-semibold'>
            <label htmlFor='password'>Password</label>
            <input type="text" name="password" className='bg-gray-300 border-2 border rounded-md pr-10 pl-2 py-1' placeholder='Enter your password' value={loginData.password} onChange={handleUserInput}  />
            </div>
            <span className='font-semibold'>Not registered ? <Link className='text-indigo-500' to={"/register"}>Register</Link></span>
            <button onClick={handleUserSubmit} className='hover:bg-indigo-700 text-white font-semibold bg-indigo-500 px-1 py-1 rounded-md'>Submit</button>
            </form>     
        </div>
    </AppLayout>
  )
}

export default Login