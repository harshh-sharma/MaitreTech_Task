import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { addItemInCart, deleteItemInCart } from '../redux/slices/cartSlice';

const Card = ({image,price,name}) => {
  const {items} = useSelector(store => store?.cart);
  const dispatch = useDispatch();
    const addItem = async() => {
      await dispatch(addItemInCart("add"));
  }
  const deleteItem = async () => {
        await dispatch(deleteItemInCart());
  }

  return (
    <div className='w-[300px] h-[300px] shadow-xl rounded-md bg-white px-2 py-2'>
        <div className='w-full h-30'>
            <img src={image} alt="" className='rounded-md w-full h-30' />
        </div>
        <div className='flex flex-col gap-1'>
            <h2>{name}</h2>
            <p>Price : {price}</p>
            <div className='flex gap-2'>
                <button className='bg-indigo-500 text-white px-4 py-1 font-bold shadow-md' onClick={() => addItem()}>+</button>
                <button className='bg-indigo-500 text-white px-4 font-bold py-1 shadow-md' onClick={() => deleteItem()}>-</button>
            </div>
        </div>
    </div>
  )
}

export default Card