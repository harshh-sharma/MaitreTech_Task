import React from 'react'
import AppLayout from '../Layout/AppLayout'
import { useDispatch, useSelector } from 'react-redux'
import { addItemInCart } from '../redux/slices/cartSlice';
import { Link } from 'react-router-dom';

const Cart = () => {
    const dispatch = useDispatch();
   
    const addItem = () => {
        // dispatch(addItemInCart());
    }
    const deleteItem = () => {
        
    }
  return (
    <AppLayout>
        <div className='w-full min-h-screen bg-gradient-to-r from-gray-200 to-blue-500 flex justify-center items-center'>
            <div className='w-[600px] min-h-[200px] bg-white px-3 py-2 rounded-md'>
                <h1 className='my-2 font-bold text-xl'>Order Summary</h1>
                <div className='flex justify-around'>
                    <div>
                        <p className='text-lg font-semibold'>Coke : </p>
                    </div>
                    <div>
                        <p className='text-lg font-semibold'>2</p>
                    </div>
                    <div className='flex gap-3'>
                    <button className='bg-indigo-500 text-white px-4 py-1 font-bold shadow-md' onClick={addItem}>+</button>
                <button className='bg-pink-500 text-white px-4 font-bold py-1 shadow-md' onClick={deleteItem}>-</button>
                    </div>
                </div>
                <div className='flex justify-around'>
                    <div>
                        <p className='text-lg font-semibold'>Fries : </p>
                    </div>
                    <div>
                        <p className='text-lg font-semibold'>2</p>
                    </div>
                    <div className='flex gap-3'>
                    <button className='bg-indigo-500 my-1 text-white px-4 py-1 font-bold shadow-md' onClick={addItem}>+</button>
                <button className='bg-pink-500 my-1 text-white px-4 font-bold py-1 shadow-md' onClick={deleteItem}>-</button>
                    </div>
                </div>
                <div className='flex justify-around'>
                    <div>
                        <p className='text-lg font-semibold'>Burger : </p>
                    </div>
                    <div>
                        <p className='text-lg font-semibold'>1</p>
                    </div>
                    <div className='flex gap-3'>
                    <button className='bg-indigo-500 text-white px-4 py-1 font-bold shadow-md' onClick={addItem}>+</button>
                <button className='bg-pink-500 text-white px-4 font-bold py-1 shadow-md' onClick={deleteItem}>-</button>
                    </div>
                </div>
                <div className='flex justify-around my-5'>
                <div className='flex gap-2 my-3'>
                <p>Total(INR) : </p>
                <p>200</p>
                </div>
                <div className='flex gap-2'>
               <Link to={"/checkout"}><button className='bg-indigo-500 text-white px-2 py-0 font-bold shadow-sm rounded-2xl
               ' onClick={addItem}>Save and checkout</button></Link>
               <button className='bg-white text-indigo-500 px-2 py-1 font-bold shadow-md rounded-md
               ' onClick={addItem}>Cancel</button>
               </div>
                </div>
            </div>
        </div>
        
    </AppLayout>
  )
}

export default Cart