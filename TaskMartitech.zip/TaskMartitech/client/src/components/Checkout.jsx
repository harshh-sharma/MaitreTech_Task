import React from 'react'
import AppLayout from '../Layout/AppLayout'
import { Link } from 'react-router-dom'

const Checkout = () => {
  return (
    <AppLayout>
        <div className='w-full bg-gradient-to-r from-gray-200 to-blue-500 min-h-screen gap-2 justify-center flex flex-col items-center'>
                <h1 className='text-4xl font-bold font-serif'>Checkout</h1>
                <p className='text-2xl font-semibold'>Thankyou for your order</p>
                <Link to={"/"}><button className='text-2xl bg-indigo-600 hover:bg-indigo-700 text-white p-2 py-1 rounded-md'>Back to Home</button></Link>
        </div>
    </AppLayout>
  )
}

export default Checkout