import React from 'react';
import {useDispatch,useSelector} from "react-redux";
import { Navigate, Outlet } from 'react-router-dom';


const Authentication = () => {
    const isLoggedIn = useSelector(store => store?.auth?.isLoggedIn);
    return (isLoggedIn ? <Outlet/> : <Navigate to={"/login"}/>)
}

export default Authentication;