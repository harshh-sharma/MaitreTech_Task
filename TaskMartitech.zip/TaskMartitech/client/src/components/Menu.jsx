import React, { useEffect } from 'react'
import AppLayout from '../Layout/AppLayout'
import Card from './Card'
import { useDispatch, useSelector } from 'react-redux'
import { getMenuData } from '../redux/slices/menuSlice'

const Menu = () => {
  const dispatch = useDispatch();
  const menu = useSelector(store => store?.menu?.data);
  console.log("menu",menu);
  useEffect(() => {
    dispatch(getMenuData());
  },[])
  return (
    <AppLayout>
        <div className='w-full min-h-screen bg-gradient-to-r from-gray-200 to-blue-500 flex justify-center items-center flex-wrap'>
            <div className='w-full flex justify-center items-center flex-wrap gap-5  mb-10'>
                {menu  && menu.map(item => <Card key={item?.id} image={item?.image} name={item?.name} price={item.price} />)}
            </div>
        </div>
    </AppLayout>
  )
}

export default Menu