import React from 'react'
import { Link } from 'react-router-dom'

const NotFoundPage = () => {
  return (
    <div className='min-h-screen flex justify-center items-center w-full bg-gray-300'>
        <div className='text-2xl font-semibold font-serif flex flex-col text-indigo-600 justify-center items-center my-2'>
            404 !! Oops Page Not Found
            <Link to={"/"}><button className='my-2 px-2 py-1 rounded-md bg-indigo-500 text-white'>Back to Home</button></Link>
        </div>
    </div>
  )
}

export default NotFoundPage