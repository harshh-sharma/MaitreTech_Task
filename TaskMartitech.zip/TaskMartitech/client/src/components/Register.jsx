import React, { useState } from 'react'
import AppLayout from '../Layout/AppLayout';
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { register } from '../redux/slices/authSlice';
import toast from 'react-hot-toast';

const Register = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [signInData,setSignInData] = useState({
        email:"",
        password:"" ,
        name:""  
     })

     const handleUserInput = (e) => {
        e.preventDefault();
        const {name,value,} = e.target;
        setSignInData({
            ...signInData,
            [name]:value
        })
     }

     const validateForm = (name,email,password) => {
        if(!name || !email || !password){
            toast.error("All fields are required");
            return false ;
        }else  if(name < 6){
            toast.error("wrong password");
            return false;
        } else if(!email.match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    )){
        toast.error("Invalid email");
        return false;
    }
    else{
        return true
    }
     }

     const handleUserSubmit = async(e) => {
        e.preventDefault();
        if(validateForm(signInData.name,signInData.email,signInData.password)){
            const response = await dispatch(register(signInData));
            console.log(response?.payload?.response?.data?.message);
            toast.error(response?.payload?.response?.data?.message)
            if(response?.payload?.success){
                navigate("/login");
            }
        }
     }

  return (
    <AppLayout>
        <div className='w-full min-h-screen bg-gradient-to-r from-gray-200 to-blue-500 rounded-md flex justify-center items-center flex-col gap-2'>
            <form className='flex flex-col gap-2 bg-gray-200 px-5 rounded-md w-[300px] py-10 '>
            <h1 className='text-xl font-semibold font-serif text-center text-indigo-500 '>Register</h1>
            <div className='flex flex-col gap-2  font-semibold'>
            <label htmlFor="email">Name</label>
            <input type="email" placeholder='Enter you Name' name="name" value={signInData.name} onChange={handleUserInput} className='bg-gray-300 border-2 rounded-md pr-10 pl-2 py-1 outline-none'/>
            </div>
            <div className='flex flex-col gap-2  font-semibold'>
            <label htmlFor="email">Email</label>
            <input type="email" placeholder='Enter you Email' name="email" value={signInData.email} onChange={handleUserInput} className='bg-gray-300 border-2  rounded-md pr-10 pl-2 py-1 outline-none'/>
            </div>
            <div className='flex flex-col gap-2 font-semibold'>
            <label htmlFor='password'>Password</label>
            <input type="text" name="password" className='bg-gray-300 border-2  rounded-md pr-10 pl-2 py-1 outline-none' placeholder='Enter your password' value={signInData.password} onChange={handleUserInput}  />
            </div>
            <span className='font-semibold'>Already registered ?  <Link to={"/Login"} className="text-indigo-500">Login</Link></span>
            <button onClick={handleUserSubmit} className='hover:bg-indigo-700 transition-all ease-in-out duration-75 text-white bg-indigo-500 px-1 py-1 rounded-md font-semibold'>Submit</button>
            </form>     
        </div>
    </AppLayout>
  )
}

export default Register;