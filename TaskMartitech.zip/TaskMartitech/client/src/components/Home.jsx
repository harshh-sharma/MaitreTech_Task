import React from 'react'
import AppLayout from '../Layout/AppLayout'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'

const Home = () => {
  const isLoggedIn = useSelector(store => store?.auth?.isLoggedIn);
  console.log(isLoggedIn);
  return (
    <AppLayout>
        <div className='w-full min-h-screen flex justify-center items-center background bg-gradient-to-r from-gray-200 to-blue-500'>
        <div className='flex my-40 flex-col py-10 justify-center items-center gap-10'>
            <h1 className='text-3xl md:text-6xl text-[#fff] text-center font-semibold font-serif'>Welcome to Food's <br/> kitchen</h1>
            {isLoggedIn ? (<Link to={"/menu"}><button className='bg-indigo-600 flex items-center justify-center text-center text-white rounded-md shadow-md px-3 py-1 font-semibold font-serif hover:bg-indigo-800 text-lg shadow-lg transition-all ease-in-out duration-75'>Go to menu</button></Link>):(<Link to={"/login"}><button className='bg-indigo-700 flex items-center justify-center text-center text-white rounded-md shadow-md px-3 py-1 font-semibold font-serif hover:bg-indigo-800 text-lg shadow-lg transition-all ease-in-out duration-75'>Go to menu</button></Link>)}
        </div>
        </div>
        
    </AppLayout>
  )
}

export default Home