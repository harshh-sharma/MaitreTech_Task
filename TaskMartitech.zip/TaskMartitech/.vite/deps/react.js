import {
  require_react
} from "./chunk-ATZAHYIB.js";
export default require_react();
//# sourceMappingURL=react.js.map
