import cookieParser from "cookie-parser";
import express from "express";
// import { User } from "./models/userModel";
import userRouter from "./routes/userRoutes.js";
import menuRouter from "./routes/menuRoutes.js";
import cors from "cors";
import morgan from "morgan";

const app = express();

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(cookieParser());
app.use(cors({
    origin:"http://localhost:5173",
    credentials:true
}));
app.use(morgan("dev"));

app.get("/",(req,res) => {
    res.send("Hello from backend");
})

app.use("/api/v1/user",userRouter);
app.use("/api/v1/menu",menuRouter);

export default app;