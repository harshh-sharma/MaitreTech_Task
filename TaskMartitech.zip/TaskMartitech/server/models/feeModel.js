import mongoose, { Mongoose } from "mongoose";

const menuModel = new mongoose.Schema({
    image:{
        type:String,
        required:true
    },
    name:{
        type:String,
        required:true
    },
    price:{
        type:String,
        required:true
    }
})

export const Menu = mongoose.model("Menu",menuModel);