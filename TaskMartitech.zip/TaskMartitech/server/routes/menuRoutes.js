import {Router} from "express";
import { create, getMenu } from "../controller/menuController.js";

const menuRouter = Router();

menuRouter.route("/")
                    .get(getMenu)
                    .post(create);

export default menuRouter;