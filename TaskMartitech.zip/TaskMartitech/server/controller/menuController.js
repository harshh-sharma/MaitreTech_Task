import { Menu } from "../models/feeModel.js";

const create = async (req,res) => {
    try {
        const {name,image,price} = req.body;
        if(!name || !image || !price){
            return res.status(400).json({
                success:false,
                message:"All field are required"
            })
        }
        const menuItem = await Menu.create({name,image,price});
        if(!menuItem){
            return res.status(500).json({
                success:false,
                message:"something went wrong"
            })
        }
        res.status(200).json({
            success:true,
            message:"MenuItem created successfully",
            menuItem
        })
    } catch (error) {
        res.status(500).json({
            success:false,
            message:error.message
        })
    }
}

const getMenu = async (req,res) => {
    try {
        const menu = await Menu.find({});
        res.status(200).json({
            success:true,
            message:"menu successfully loaded",
            menu
        })
    } catch (error) {
        res.status(500).json({
            success:false,
            message:error.message
    })
    }
}

export {
    create,
    getMenu
}