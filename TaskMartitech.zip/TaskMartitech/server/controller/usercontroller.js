import { User } from "../models/userModel.js";

const register = async (req,res) => {
    try {
        const {name,email,password} = req.body;
        if(!name || !email || !password){
            return res.status(400).json({
                success:false,
                message:"All fields are required"
            })
        }
        const isUserExits =  await User.findOne({email});
        if(isUserExits){
            return res.status(400).json({
                success:false,
                message:"Already user registered"
            })
        }

        const user = await User.create({name,email,password});
        if(!user){
            return res.status(500).json({
                success:false,
                message:"something went wrong"
            })
        }

        res.status(200).json({
            success:true,
            message:"user successfully registered",
            user
        })

    } catch (error) {
        res.status(500).json({
            success:false,
            message:error.message
        })
    }
}

const login = async (req,res) => {
    try {
        const {email,password} = req.body;
        console.log(email,password);
        if(!email || !password){
            return res.status(400).json({
                success:false,
                message:"All fields are required"
            })
        }
        const user = await User.findOne({email});
        if(!user){
            return res.status(500).json({
                    success:false,
                    message:"something went wrong"
            })
        }

        const isPasswordCorrect = await user.correctPassword(password);
        if(!isPasswordCorrect){
            return res.status(400).json({
                success:false,
                message:"something went wrong"
            })
        }
        // console.log("yes");
        res.status(200).json({
            success:true,
            message:"user successfully loggedIn",
            user
        })
    } catch (error) {
        res.status(500).json({
            success:false,
            message:error.message
        })
    }
}

export {
    register,
    login
}